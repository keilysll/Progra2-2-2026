#include "Pintura.h"

Pintura::Pintura(string titulo, int precio, int ancho, int alto):Obra(titulo,precio)
{
	this->ancho = ancho;
	this->alto = alto;
}

Pintura::~Pintura()
{
}

int Pintura::getAncho()
{
	return ancho;
}

int Pintura::getAlto()
{
	return alto;
}

string Pintura::toJson()
{
	stringstream ss;
	ss << "{\"nombre\":\""<<titulo<<"\",\"precio\":"<<precio<<",\"alto\":"<<ancho<<",\"ancho\":"<<alto<<"}";
	return ss.str();
}
