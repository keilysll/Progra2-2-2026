#include "Museo.h"


Museo::Museo(string nombre, string direccion):exposiciones(10),artistas(10)
{
	this->nombre = nombre;
	this-> direccion = direccion;
}

Museo::~Museo()
{
}
/*
ModExposicion& Museo::getExposiciones()
{
	return exposiciones;
}
*/
/*
ModArtista& Museo::getArtistas()
{
	return artistas;
}
*/
void Museo::registrarExposicion(int nro)
{
	Exposicion* e = new Exposicion(nro);
	exposiciones.registrar(e);	
}

void Museo::registrarArtistaEnExposicion(int nro, Artista* a)
{
	Exposicion* e = exposiciones.buscar(new Exposicion(nro));
	if (e != NULL)
	{
		e->registrar(a);
	}
}

void Museo::registrarObraEnExposicion(int nro, string nombre, Obra* o)
{
	Exposicion* e = exposiciones.buscar(new Exposicion(nro));
	if (e != NULL)
		
	{
		Artista* a = e->buscar(new Artista(nombre));
		if (a != NULL)
		{
			a->registrar(o);
		}
	}
}


string Museo::toJson()
{
	stringstream ss;
	ss << "{\"nombre\":\"" << nombre << "\",\"dirreccion\":\"" << direccion << "\",\"exposiciones\":" << exposiciones.toJson(Exposicion::toJson) << "}";
	return ss.str();
}
