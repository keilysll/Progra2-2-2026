#include "Obra.h"

Obra::Obra(string titulo)
{
	this->titulo = titulo;
	ContObj::getIns().incrObras();
}

Obra::Obra(string titulo, int precio)
{
	this->titulo = titulo;
	this->precio = precio;
	ContObj::getIns().incrObras();
}

Obra::~Obra()
{
}

string Obra::getTitulo()
{
	return titulo;
}

int Obra::getPrecio()
{
	return precio;
}
string Obra::toJson(Obra* o)
{
	return o->toJson();
}

bool Obra::cmpTituloAsc(Obra* o1, Obra* o2)
{
	return o1->titulo > o2->titulo;
}

bool Obra::cmpTituloDesc(Obra* o1, Obra* o2)
{
	return o1->titulo < o2->titulo;
}

bool Obra::operator==(Obra* o)
{
	return titulo == o->titulo;
}
