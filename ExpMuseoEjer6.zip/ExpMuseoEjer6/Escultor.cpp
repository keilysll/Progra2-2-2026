#include "Escultor.h"

Escultor::Escultor(string nombre, string material):Artista(nombre)
{
	this->material = material;
}

Escultor::~Escultor()
{
}

string Escultor::getMaterial()
{
	return material;
}

string Escultor::toJson()
{
	stringstream ss;
	ss << "{\"nombre\":\""<<nombre<<"\",\"materiales\":\"" << material<< "\",\"obras\":"<<obras.toJson(Obra::toJson)<<"}";
	return ss.str();
}
