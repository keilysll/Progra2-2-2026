#pragma once
#include <iostream>
#include <string>
#include <sstream>
using namespace std;
#include"Artista.h"
#include"ListaArray.h"
class Exposicion
{
private:
	ListaArray<Artista> artistas;
	int nro;

public:
	Exposicion(int nro);
	~Exposicion();
	int getNro();
	//ModArtista& getArtistas();
	void registrar(Artista* a);
	//Artista* buscar(string nombre);
	string toJson();
	bool operator== (Exposicion* e);
	static string toJson(Exposicion* e);



};

