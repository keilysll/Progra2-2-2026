#include "Artista.h"

Artista::Artista(string nombre):obras(10)
{
	this->nombre = nombre;

}

Artista::~Artista()
{
}

string Artista::getNombre()
{
	return nombre;
}
/*
ModObras& Artista::getObras()
{
	return obras;
}
*/
void Artista::registrar(Obra* o)
{
	obras.registrar(o);
}

bool Artista::operator==(Artista* a)
{
	return nombre == a->nombre;
}

string Artista::toJson(Artista* a)
{
	return a->toJson();
}

