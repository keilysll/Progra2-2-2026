#include "Pintor.h"

Pintor::Pintor(string nombre, string especialidad):Artista(nombre)
{
	this->especialidad = especialidad;
}

Pintor::~Pintor()
{
}

string Pintor::getEspecialidad()
{
	return especialidad;
}

string Pintor::toJson()
{
	stringstream ss;
	ss << "{\"nombre\":\""<<nombre<<"\",\"especialidad\":\""<<especialidad<<"\",\"obras\":"<<obras.toJson(Obra::toJson)<<"}";
	return ss.str();
}
