#include "ContObj.h"
ContObj::ContObj()
{
	contObras = 0;
}

ContObj& ContObj::getIns()
{
	static 	ContObj inst;
	return inst;
}

ContObj::~ContObj()
{
}

void ContObj::incrObras()
{
	contObras;
}

int ContObj::getCont()
{
	return contObras;
}
