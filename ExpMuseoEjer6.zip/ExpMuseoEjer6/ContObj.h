#pragma once
#include <iostream>
#include <string>
#include <sstream>
using namespace std;
class ContObj
{
private:
	int contObras;

public:
	static ContObj& getIns();
	~ContObj();
	void incrObras();
	int getCont();
private:
	ContObj();
};

