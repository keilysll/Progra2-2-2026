#pragma once
#include <iostream>
#include <string>
#include <sstream>
using namespace std;
#include"ContObj.h"
class Obra
{
protected:
	string titulo;
	int precio;
public:
	Obra(string titulo);
	Obra(string titulo,int precio);
	~Obra();
	string getTitulo();
	int getPrecio();
	bool operator  == (Obra* o);// buscar generico
	virtual string toJson() = 0;
	static string toJson(Obra* o); // tojson generico
	static bool cmpTituloAsc(Obra* o1 , Obra* o2);// ordenar generico
	static bool cmpTituloDesc(Obra* o1, Obra* o2);



};

