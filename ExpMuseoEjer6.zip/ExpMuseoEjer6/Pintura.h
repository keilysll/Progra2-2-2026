#pragma once
#include "Obra.h"
class Pintura :
    public Obra
{
private:
    int alto; 
    int ancho;
public:
    Pintura(string titulo , int precio , int ancho , int alto);
    ~Pintura();
    int getAncho(); 
    int getAlto();
    string toJson();
};

