#pragma once
//#include"ModExposicion.h"
#include"Exposicion.h"
#include"Artista.h"
#include"Pintor.h"
#include"Escultor.h"
#include"ListaArray.h"
class Museo
{
private:
	string nombre;
	string direccion;
	//ModExposicion exposiciones;
	ListaArray<Exposicion> exposiciones;
	ListaArray<Artista> artistas;
public:
	Museo(string nombre, string direccion);
	~Museo();
	//ModExposicion& getExposiciones();
	//ModArtista& getArtistas();
	void registrarExposicion(int nro);
	void registrarArtistaEnExposicion(int nro,Artista * a);
	void registrarObraEnExposicion(int nro , string nombre, Obra* o);
	string toJson();

};

