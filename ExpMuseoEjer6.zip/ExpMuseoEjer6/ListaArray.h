#pragma once
#include<iostream>
#include<sstream>
#include<string>
using namespace std;
template<class T>

class ListaArray
{
private:
	T** datos;
	int tam;
	int ind;

public:
	ListaArray(int tam);
	~ListaArray();
	void registrar(T* dato);
	T* buscar(T* dato);
	string toJson(string(*tojson)(T*));
	void ordenar(bool(*cmp) (T*,T*));

	//T* obtener(int dato);
	//int getInd();
};

template<class T>
ListaArray<T>::ListaArray(int tam)
{
	ind = 0;
	this->tam = tam;
	datos = new T * [tam];
}

template<class T>
ListaArray<T>::~ListaArray()
{
	delete[] datos;
}

template<class T>
void ListaArray<T>::registrar(T* dato)
{
	if (ind < tam)
	{
		datos[ind] = dato;
		ind++;
	}
}

template<class T>
T* ListaArray<T>::buscar(T* dato)// tener otro constructor para realizar la busqueda
{
	for (int i = 0; i < ind; i++)
	{
		if (*(datos[i]) == dato) //sobrecarga de operadores
		{
			return datos[i];
		}
	}
	return NULL;
}

template<class T>
string ListaArray<T>::toJson(string(*json)(T*)) //(string(*f)(T*))
{
	stringstream ss;
	ss << "[";
	for (int i = 0; i < ind; i++)
	{
		ss << (*json)(datos[i]); // crear funcion estatica
		if (i < ind - 1)
		{
			ss << ",";
		}
	}
	ss << "]";
	return ss.str();
}

template<class T>
void ListaArray<T>::ordenar(bool(*cmp) (T*, T*))
{
	for (int i = 0; i < ind-1; i++)
	{
		for (int j = 0; j < ind-1; j++)
		{
			if ((*cmp) (datos[j],(datos[j + 1]))
			{
				swap(datos[j],datos[j+1]);
			}
		}
	}
}
