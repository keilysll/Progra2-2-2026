#pragma once
#include <iostream>
#include <string>
#include <sstream>
using namespace std;
#include"Obra.h"
#include"ListaArray.h"
#include"Escultura.h"
#include"Pintura.h"
class Artista
{
protected:
	string nombre;
	//ModObras obras;
	ListaArray<Obra> obras;

public:
	Artista(string nombre);
	~Artista();
	string getNombre();
	//ModObras& getObras();
	void registrar(Obra* o);
	virtual string toJson()= 0;
	bool operator== (Artista* a);
	static string toJson(Artista* a);


};

