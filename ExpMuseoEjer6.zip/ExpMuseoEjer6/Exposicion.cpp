#include "Exposicion.h"

Exposicion::Exposicion(int nro):artistas(10)
{
    this->nro = nro;
}

Exposicion::~Exposicion()
{
}

int Exposicion::getNro()
{
    return nro;
}
/*
ModArtista& Exposicion::getArtistas()
{
    return artistas;
}
*/
void Exposicion::registrar(Artista* a)
{
    artistas.registrar(a);
}
/*
Artista* Exposicion::buscar(string nombre)
{
    return artistas.buscar(nombre);
}
*/
string Exposicion::toJson()
{
    stringstream ss;
    ss << "{\"numero\":"<<nro<<",\"artistas\":"<<artistas.toJson(Artista::toJson)<<"}";
    return ss.str();
}

bool Exposicion::operator==(Exposicion* e)
{
    return nro == e->nro;
}

string Exposicion::toJson(Exposicion* e)
{
    return e->toJson();
}

