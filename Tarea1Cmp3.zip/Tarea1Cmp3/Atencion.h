#pragma once
#include"ModGenerico.h"
#include"Cliente.h"
#include"Mesa.h"
class Atencion
{
private:
	int nro;
	Mesa* mesa;
	ModGenerico<Cliente> clientes;
public:
	Atencion(int nro, Mesa* mesa);
	~Atencion();
	int getNro();
	string toJson();
	bool operator <<(Cliente * c);
};

