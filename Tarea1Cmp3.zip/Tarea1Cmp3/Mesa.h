#pragma once
using namespace std;
#include<iostream>
#include<sstream>
#include<string>
class Mesa
{
private:
	string codigo;
	int capacidad;
public:
	Mesa(string codigo,int capacidad);
	~Mesa();
	string getCodigo();
	int getCap();
	string toJson();
};

