#include "Mesa.h"

Mesa::Mesa(string codigo, int capacidad)
{
	this->codigo = codigo;
	this->capacidad = capacidad;
}

Mesa::~Mesa()
{
}

string Mesa::getCodigo()
{
	return codigo;
}

int Mesa::getCap()
{
	return capacidad;
}

string Mesa::toJson()
{
	stringstream ss;
	ss << "{\"codigo\":\""<<codigo<<"\",\"capacidad\":"<<capacidad<<"}";
	return ss.str();
}
