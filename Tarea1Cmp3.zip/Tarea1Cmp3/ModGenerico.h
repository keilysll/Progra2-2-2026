#pragma once
using namespace std;
#include<iostream>
#include<sstream>
#include<string>
template<class T>

class ModGenerico
{
private:
	T** datos;
	int tam; 
	int ind;

public:
	ModGenerico(int tam);
	~ModGenerico();
	void registrar(T* dato);
	void operator<<(T* dato);
	T* buscar(T* dato);
	string toJson(string (*json),T*);
	T* operator[](int ind);
	
};

template<class T>
ModGenerico<T>::ModGenerico(int tam)
{
	this->tam = tam;
	ind = 0;
	datos = new T * [tam];

}

template<class T>
ModGenerico<T>::~ModGenerico()
{
	delete[] datos;
}

template<class T>
void ModGenerico<T>::registrar(T* dato)
{
	if (ind < tam)
	{
		datos[ind] = dato;
		ind++;
	}
}

template<class T>
void ModGenerico<T>::operator<<(T* dato)
{
	if (ind < tam)
	{
		datos[ind] = dato;
		ind++;
	}
}

template<class T>
T* ModGenerico<T>::buscar(T* dato)
{
	for (int i = 0; i < ind; i++)
	{
		if (*(datos[i]) == dato)
		{
			return datos[i];
		}
	}
	return NULL;
}

template<class T>
string ModGenerico<T>::toJson(string(*json), T*)
{
	stringstream ss;
	ss << "[";
	for (int i = 0; i < ind; i++)
	{
		ss << (*json)(datos[i]);

		if (i < ind - 1)
		{
			ss << ",";
		}
	}
	ss << "]";
	return ss.str();
}

template<class T>
T* ModGenerico<T>::operator[](int ind)
{
	return datos[ind];
}
