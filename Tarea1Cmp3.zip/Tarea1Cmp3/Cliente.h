#pragma once
using namespace std;
#include<iostream>
#include<sstream>
#include<string>

class Cliente
{
private:
	string nombre;
public:
	Cliente(string nombre);
	~Cliente();
	string getNombre();
	string toJson();
};

