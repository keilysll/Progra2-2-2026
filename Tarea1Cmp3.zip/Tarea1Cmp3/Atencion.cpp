#include "Atencion.h"

Atencion::Atencion(int nro, Mesa* mesa):clientes(10)
{
	this->nro = nro;
	this->mesa = mesa;
}

int Atencion::getNro()
{
	return nro;
}

string Atencion::toJson()
{
	stringstream ss;
	ss << "{\"numero\":"<<nro<<",\"mesa\":"<<mesa->toJson()<<",\"clientes\":"<<clientes.toJson()<<"}";
	return ss.str();
}

bool Atencion::operator<<(Cliente* c)
{
   clientes.registrar(c);
}
