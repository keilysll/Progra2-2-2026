#pragma once
#include"Chat.h"

class ModChat
{
	
	private:
		Chat** chats;
		int tam;
		int ind;
	public:
		ModChat(int tam);
		~ModChat();
		int getTam();
		int getInd();
		void registrar(Chat* c);
		Chat* buscar(int num);
		string toString();

};

