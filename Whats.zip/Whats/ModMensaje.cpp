#include "ModMensaje.h"

ModMensaje::ModMensaje(int tam)
{
	this->tam = tam;
	this->ind = 0;
	mensajes = new Mensaje * [tam];
}

ModMensaje::~ModMensaje()
{
	delete[] mensajes;
}

int ModMensaje::getTam()
{
	return tam;
}

int ModMensaje::getInd()
{
	return ind;
}

void ModMensaje::registrar(Mensaje* m)
{
	if (ind < tam)
	{
		mensajes[ind] = m;
		ind++;
	}
}

string ModMensaje::toString()
{
	stringstream ss;

	for (int i = 0; i < ind; i++)
	{
		ss << mensajes[i]->toString();
		if (i < ind - 1)
		{
			ss << ",";
		}

	}
	ss << "]";
	return ss.str();
}
