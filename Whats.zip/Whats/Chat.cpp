#include "Chat.h"

Chat::Chat(int nro): mensajes(10)
{
	this->nro = nro;
}

Chat::~Chat()
{
}

ModMensaje& Chat::getMensajes()
{
	return mensajes;
}

string Chat::toString()
{
	stringstream ss;
	ss << "{\"telefono\":"<<nro<<",\"mensajes\":"<<mensajes.toString()<<"}";
	return ss.str();
}

int Chat::getNro()
{
	return nro;
}

void Chat::registrar(Mensaje* m)
{
	mensajes.registrar(m);
}
