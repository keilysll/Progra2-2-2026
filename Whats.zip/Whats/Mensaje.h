#pragma once
using namespace std;
#include<iostream>
#include<sstream>
#include<string>
class Mensaje
{
protected:
	int nroDestino;

public:

	Mensaje(int nroDestino);
	~Mensaje();
	int getNroDestino();
	virtual string toString() = 0;

};

