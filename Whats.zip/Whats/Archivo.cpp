#include "Archivo.h"

Archivo::Archivo(int nroDestino, string nombre, string extension):Mensaje(nroDestino)
{
	this->nombre = nombre;
	this->extension = extension;
}

Archivo::~Archivo()
{
}

string Archivo::getNombre()
{
	return nombre;
}

string Archivo::getExtension()
{
	return extension;
}

string Archivo::toString()
{
	stringstream ss;
	ss << "{\"autor\":"<<nroDestino<<",\"tipo\":\"archivo\",\"nombre\":\""<<nombre<<"\",\"ext\":\""<<extension<<"\"}";
	return ss.str();
}
