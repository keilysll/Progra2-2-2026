#include "Mensaje.h"

Mensaje::Mensaje(int nroDestino)
{
	this->nroDestino = nroDestino;
}

Mensaje::~Mensaje()
{
}

int Mensaje::getNroDestino()
{
	return nroDestino;
}
