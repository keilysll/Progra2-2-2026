#include "Texto.h"

Texto::Texto(int nroDestino, string frase):Mensaje(nroDestino)
{
	this->frase = frase;
}

Texto::~Texto()
{
}

string Texto::getFrase()
{
	return frase;
}

string Texto::toString()
{
	stringstream ss;
	ss << "{\"autor\":"<<nroDestino<<",\"tipo\":\"texto\",\"contenido\":\""<<frase<<"\"}";
	return ss.str();
}
