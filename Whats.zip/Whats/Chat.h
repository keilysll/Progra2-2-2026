#pragma once
#include"ModMensaje.h"
using namespace std;
class Chat
{
private: 
	int nro;
	ModMensaje mensajes;
public:
	Chat(int nro);
	~Chat();
	ModMensaje& getMensajes();
	string toString();
	int getNro();
	void registrar(Mensaje* m);
};

