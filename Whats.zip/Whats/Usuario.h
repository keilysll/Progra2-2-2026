#pragma once
using namespace std;
#include<iostream>
#include<sstream>
#include<string>
#include"ModChat.h"
class Usuario
{
private:
	int fono;
	string nombre;
	ModChat chats;

public:
	Usuario(int fono,string nombre);
	~Usuario();
	int getFono();
	ModChat& getChats();
	string getNombre();
	string toString();
	void enviarMensaje(Mensaje * m, int destino);
	void recibirMensaje(Mensaje * m);
};

