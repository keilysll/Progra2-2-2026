#pragma once
#include"Mensaje.h"
#include"Texto.h"
#include"Archivo.h"

class ModMensaje
{
private:
	Mensaje** mensajes;
	int tam;
	int ind;
public:
	ModMensaje(int tam);
	~ModMensaje();
	int getTam();
	int getInd();
	void registrar(Mensaje * m);
	//Mensaje* buscar();
	string toString();
};

