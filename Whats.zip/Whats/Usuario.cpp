#include "Usuario.h"

Usuario::Usuario(int fono, string nombre):chats(10)
{
	this->fono = fono;
	this->nombre = nombre;
}

Usuario::~Usuario()
{
}

int Usuario::getFono()
{
	return fono;
}

ModChat& Usuario::getChats()
{
	return chats;
}

string Usuario::getNombre()
{
	return nombre;
}

string Usuario::toString()
{
	stringstream ss;
	ss << "{\"telefono\":"<<fono<<",\"nombre\":\""<<nombre<<"\",\"chats\":"<<chats.toString()<<"}";
	return ss.str();
}

void Usuario::enviarMensaje(Mensaje* m, int destino)
{

	Chat* dest = chats.buscar(destino);

	if (dest == nullptr)
	{
		dest = new Chat(destino);
		chats.registrar(dest);
	}
	dest->getMensajes().registrar(m);

}

void Usuario::recibirMensaje(Mensaje* m)
{
	Chat* chat = chats.buscar(m->getNroDestino());
	if (chat == nullptr)
	{
		chat = new Chat (m->getNroDestino())// completar
	}
	
}
