#pragma once
#include "Mensaje.h"
class Texto :
    public Mensaje

{
private:
    string frase;

public:
    Texto(int nroDestino, string frase);
    ~Texto();
    string getFrase();
    string toString();

};

