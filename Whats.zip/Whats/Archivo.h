#pragma once
#include "Mensaje.h"
class Archivo :
    public Mensaje
{
private:
    string nombre;
    string extension;
public:
    Archivo(int nroDestino,string nombre, string extension);
    ~Archivo();
    string getNombre();
    string getExtension();
    string toString();
};

