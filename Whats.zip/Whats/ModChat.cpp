#include "ModChat.h"
ModChat::ModChat(int tam)
{
	this->tam = tam;
	this->ind = 0;
	chats = new Chat * [tam];
}

ModChat::~ModChat()
{
	delete[] chats;
}

int ModChat::getTam()
{
	return tam;
}

int ModChat::getInd()
{
	return ind;
}

void ModChat::registrar(Chat* c)
{
	if (ind < tam)
	{
		chats[ind] = c;
		ind++;
	}
}

Chat* ModChat::buscar(int num)
{
	for (int i = 0; i < ind; i++)
	{
		if (chats[i]->getNro() == num)
		{
			return chats[i];
		}
	}
	return NULL;
}

string ModChat::toString()
{
	stringstream ss;

	for (int i = 0; i < ind; i++)
	{
		ss << chats[i]->toString();
		if (i < ind - 1)
		{
			ss << ",";
		}

	}
	ss << "]";
	return ss.str();
}
