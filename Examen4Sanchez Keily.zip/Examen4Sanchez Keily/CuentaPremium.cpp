#include "CuentaPremium.h"

CuentaPremium::CuentaPremium(int nro, string titular):Cuenta(nro,titular)
{
}

CuentaPremium::~CuentaPremium()
{
}

string CuentaPremium::toJson()
{
	stringstream ss;
	ss << "{\"numero\":"<<nro<<",\"titular\":\""<<titular<<"\",\"tipo\":\"premium""\",\"saldo\":"<<saldo<<",\"movimientos\":"<<movimientos.toJson(Movimiento::toJsonPtr)<<"}";
	return ss.str();
}

int CuentaPremium::limiteDiario()
{
	return 1000;
}

int CuentaPremium::cashback(int monto)
{
	if (monto >= 50)
		monto = monto + 1;
	return monto;
}

int CuentaPremium::comision()
{
	return 0;
}

string CuentaPremium::tipo()
{
	return "premium";
}
