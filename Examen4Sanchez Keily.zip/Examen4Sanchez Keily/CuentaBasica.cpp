#include "CuentaBasica.h"

CuentaBasica::CuentaBasica(int nro, string titular):Cuenta(nro,titular)
{
	saldo = 0;
}

CuentaBasica::~CuentaBasica()
{
}

string CuentaBasica::toJson()
{
	stringstream ss;
	ss << "{\"numero\":"<<nro<<",\"titular\":\""<<titular<<"\",\"tipo\":\"basica""\",\"saldo\":"<<saldo<<",\"movimientos\":"<<movimientos.toJson(Movimiento::toJsonPtr)<<"}";
	return ss.str();
}

int CuentaBasica::limiteDiario()
{
	return 300;
}

int CuentaBasica::cashback(int monto)
{
	monto = monto + 0;
	return monto;
}

int CuentaBasica::comision()
{
	return 2;
}

string CuentaBasica::tipo()
{
	return "basica";
}
