#include "Cuenta.h"

Cuenta::Cuenta(int nro, string titular)
{
	this->nro = nro;
	this->titular = titular;
	this->saldo = saldo;
}

Cuenta::~Cuenta()
{
}

int Cuenta::getNro()
{
	return nro;
}

string Cuenta::getTitular()
{
	return titular;
}

void Cuenta::registrar(Movimiento* m)
{
	if (m->getMonto() > limiteDiario())
		//throw exception(("la transaccion " + m->getId() + " supera el limite diario de la cuenta " + nro).c_str());
	if (m->getMonto() == 0)
		//throw exception(("monto invalido en la transaccion" + m->getId()).c_str());


	movimientos.registrar(m);
}

string Cuenta::toJsonPtr(Cuenta* c)
{
	return c->toJson();
}
