#pragma once
#include<iostream>
#include<sstream>
#include<string>
#include"Movimiento.h"
#include"PagoQR.h"
#include"Recarga.h"
#include"ListaEnlazada.h"
using namespace std;
class Cuenta
{
protected:
	int nro;
	string titular;
	ListaEnlazada<Movimiento> movimientos;
	int saldo;
public:
	Cuenta(int nro,string titular);
	~Cuenta();
	int getNro();
	string getTitular();
	virtual string toJson() = 0;
	virtual int limiteDiario() = 0;
	virtual int cashback(int monto) = 0;
	virtual int comision() = 0;
	virtual string tipo() = 0;
	void registrar(Movimiento* m);
	static string toJsonPtr(Cuenta* c);	
	int revertir(int nro);
	int totalCashback();

};

