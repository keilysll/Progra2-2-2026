#pragma once
#include"Cuenta.h"
#include"ListaEnlazada.h"
class Billetera
{
private:
	string nombre;

public:
	Billetera(string nombre);
	~Billetera();
};

