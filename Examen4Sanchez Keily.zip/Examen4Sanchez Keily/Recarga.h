#pragma once
#include "Movimiento.h"
class Recarga :
    public Movimiento
{
    public:
        Recarga(int id,int fecha, int monto);
        ~Recarga();
        string toJson();
        int Abono(int ingresos);
};

