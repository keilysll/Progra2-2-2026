#include "PagoQR.h"

PagoQR::PagoQR(int id, int fecha, int monto, string comercio):Movimiento(id,fecha,monto)
{
	this->comercio = comercio;
}

PagoQR::~PagoQR()
{
}

string PagoQR::getComercio()
{
	return comercio;
}

string PagoQR::toJson()
{
	stringstream ss;
	ss << "{\"id\":"<<id<<",\"fecha\":"<<fecha<<",\"tipo\":\"pagoqr\",\"monto\":"<<monto<<",\"comercio\":\""<<comercio<<"\",\"cashback\":2,\"revertido\":false}";
	return ss.str();
}



int PagoQR::Transferencia(int egresos)
{
	monto = monto - egresos;
	return monto;
}

string PagoQR::revertir()
{
	return "false";
}


