#include "Recarga.h"

Recarga::Recarga(int id, int fecha, int monto):Movimiento(id,fecha,monto)
{
}

Recarga::~Recarga()
{
}

string Recarga::toJson()
{
	stringstream ss;
	ss << "{\"id\":"<<id<<",\"fecha\":"<<fecha<<",\"tipo\":\"recarga\",\"monto\":"<<monto<<"}";
	return ss.str();
}

int Recarga::Abono(int ingresos)
{
	monto = monto + ingresos;
	return monto;
}
