#pragma once
#include "Cuenta.h"
class CuentaBasica :
    public Cuenta
{
public:
    CuentaBasica(int nro, string titular);
    ~CuentaBasica();
    string toJson();
    int limiteDiario();
    int cashback(int monto);
    int comision();
   string tipo();
};

