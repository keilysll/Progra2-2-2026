#pragma once
#include<iostream>
#include<sstream>
#include<string>
using namespace std;
class Movimiento
{
protected:
	int id;
	int fecha;
	int monto;

public:
	Movimiento(int id, int fecha,int monto);
	~Movimiento();
	int getId();
	int getFecha();
	int getMonto();
	virtual string toJson() = 0;
	static  string toJsonPtr(Movimiento* m);
};

