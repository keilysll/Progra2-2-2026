#pragma once
#include "CuentaPremium.h"
class CuentaEmpresarial :
    public CuentaPremium
{
private:
    int nit;

public:
    CuentaEmpresarial(int nro, string titular,int nit);
    ~CuentaEmpresarial();
    int getnIt();
    int limiteDiario();
   // string toJson();
};

