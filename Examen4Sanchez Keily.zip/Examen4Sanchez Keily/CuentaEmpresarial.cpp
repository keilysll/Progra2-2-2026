#include "CuentaEmpresarial.h"

CuentaEmpresarial::CuentaEmpresarial(int nro, string titular, int nit):CuentaPremium(nro,titular)
{
	this->nit = nit;
	saldo = 0;
}

CuentaEmpresarial::~CuentaEmpresarial()
{
}

int CuentaEmpresarial::getnIt()
{
	return nit;
}

int CuentaEmpresarial::limiteDiario()
{
	return 5000;
}
