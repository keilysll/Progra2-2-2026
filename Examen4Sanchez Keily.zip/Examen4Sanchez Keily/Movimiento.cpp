#include "Movimiento.h"

Movimiento::Movimiento(int id, int fecha, int monto)
{
	this->id = id;
	this->fecha = fecha;
	this->monto = monto;

}

Movimiento::~Movimiento()
{
}

int Movimiento::getId()
{
	return id;
}

int Movimiento::getFecha()
{
	return fecha;
}

int Movimiento::getMonto()
{
	return monto;
}

string Movimiento::toJsonPtr(Movimiento* m)
{
	return m->toJson();
}
