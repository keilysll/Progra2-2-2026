#pragma once
#include "Cuenta.h"
class CuentaPremium :
    public Cuenta
{
public:
    CuentaPremium(int nro, string titular);
    ~CuentaPremium();
    string toJson();
    int limiteDiario();
    int cashback(int monto);
    int comision();
    string tipo();
  
};

