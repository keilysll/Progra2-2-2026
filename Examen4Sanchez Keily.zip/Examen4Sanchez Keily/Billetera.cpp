#include "Billetera.h"

Billetera::Billetera(string nombre)
{
	this->nombre = nombre;
}

Billetera::~Billetera()
{
}
