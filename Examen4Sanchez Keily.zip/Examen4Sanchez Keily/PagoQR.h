#pragma once
#include "Movimiento.h"
class PagoQR :
    public Movimiento
{
private:
    string comercio;
public:
    PagoQR(int id, int fecha,int monto,string comercio);
    ~PagoQR();
    string getComercio();
    string toJson();
    int Transferencia(int egresos);
    string revertir();
};

