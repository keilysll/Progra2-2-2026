/*
Una billetera digital desea un sistema para controlar las cuentas de sus usuarios,
que realizan recargas, pagos con codigo QR en comercios y transferencias entre cuentas.
Se debe considerar:
- Registrar cuentas en la billetera (ordenadas por numero, sin numeros repetidos).
- Registrar recargas y pagos QR en una cuenta, y revertir pagos QR.
- Realizar transferencias entre cuentas de la billetera.
- Mejorar una cuenta basica a premium.
- Obtener reportes y una descripcion breve de cada cuenta.

JERARQUIA OBLIGATORIA
- Cuenta (abstracta) con metodos virtuales puros: limiteDiario(), comision(), cashback(monto), tipo().
	- CuentaBasica:      limite diario 300, comision por transferencia 2, sin cashback.
	- CuentaPremium:     limite diario 1000, sin comision, cashback en pagos QR de
						 1 Bs por cada 50 Bs pagados (division entera), abonado al saldo.
		- CuentaEmpresarial(numero, titular, nit): hereda de CuentaPremium (mismo cashback
						 y comision), pero su limite diario es 5000. Su JSON incluye "nit".

- Movimiento (abstracta) con metodo virtual puro tipo().
	- Recarga, Abono (ingresos);  PagoQR, Transferencia (egresos).
No se permite distinguir tipos de cuenta o de movimiento con atributos de texto, enumeraciones
ni if/switch sobre tipo(): el tipo real se identifica con dynamic_cast<>, que es OBLIGATORIO en:
  * Cuenta::registrar (saber que clase de movimiento llega),
  * revertir (solo se puede revertir un PagoQR),
  * mejorarCuenta (solo se puede mejorar una CuentaBasica),
  * los reportes de cashback y comisiones (datos que solo existen en PagoQR / Transferencia),
  * contar<T>() (una CuentaEmpresarial tambien cuenta como CuentaPremium).

REGLAS (todos los montos son enteros, en Bs)
Al registrar un egreso se valida en este orden; si una regla falla se lanza la excepcion
y NO se modifica nada:
1. El monto debe ser mayor a 0: "monto invalido en la transaccion <id>" (tambien en ingresos).
2. Los egresos del dia (pagos QR no revertidos + transferencias enviadas con la misma fecha,
   sin contar comisiones) no pueden superar el limite diario:
   "la transaccion <id> supera el limite diario de la cuenta <numero>".
3. El saldo debe cubrir monto + comision:
   "saldo insuficiente en la cuenta <numero> para la transaccion <id>".
Una transaccion que falla no se registra y no cuenta para el limite.
Transferencias: primero se buscan origen y destino ("cuenta <numero> no encontrada");
se registra "transferencia" en el origen y "abono" (mismo id) en el destino.
Reversion de un pago QR (revertir(idPago)):
   "transaccion <id> no encontrada en la cuenta <numero>"
   "la transaccion <id> no es un pago QR"
   "el pago <id> ya fue revertido"
   Al revertir se devuelve al saldo el monto menos el cashback recibido; el pago queda en el
   detalle con "revertido":true, deja de contar para el limite diario y su cashback deja de
   contar en los reportes.
Mejorar cuenta (mejorarCuenta(numero)): "la cuenta <numero> no es basica". La cuenta
   premium conserva numero, titular, saldo y movimientos, y desde ese momento aplica las
   reglas premium.

INTERFAZ REQUERIDA
Movimientos: Recarga(id, fecha, monto), PagoQR(id, fecha, monto, comercio).
   (Transferencia y Abono los crea la billetera al transferir.)
Cuenta:
   CuentaBasica(numero, titular), CuentaPremium(numero, titular),
   CuentaEmpresarial(numero, titular, nit); toda cuenta inicia con saldo 0.
   void registrar(Movimiento* m)     la cuenta pasa a ser duena del movimiento
									 (si falla, lo libera)
   void revertir(int idPago)
   int totalCashback()               cashback de pagos QR no revertidos
   string descripcion()              ej: [basica] 70011 ana: 30 Bs
   bool esIgual(const Cuenta& otra)  compara solo el numero
   string toJson()
Billetera(nombre):
   void registrarCuenta(Cuenta* c)   "la cuenta <numero> ya existe"
   Cuenta* buscar(int numero)        "cuenta <numero> no encontrada"
   void registrar(int numero, Movimiento* m)
   void transferir(int id, int fecha, int origen, int destino, int monto)
   void revertir(int numero, int idPago)
   void mejorarCuenta(int numero)
   int totalCashback()               suma del cashback vigente de todas las cuentas
   int totalComisiones()             suma de comisiones cobradas en transferencias
   int saldoTotal()                  suma de saldos
   string cuentaMayorSaldo()         titular de la cuenta con mayor saldo
   template <class T> int contar()   cuentas cuyo tipo real es T o deriva de T
   string toJson()
*/
#include "Billetera.h"

//cuenta basica cash back 0
// cuenta premiun en cada 50 
#include<iostream>
using namespace std;
#include"CuentaBasica.h"
#include"CuentaPremium.h"
int pregunta1()
{
	cout << "----Pregunta 1----" << endl;
	cout<<"{\"numero\":70011,\"titular\":\"ana\",\"tipo\":\"basica\",\"saldo\":30,\"movimientos\":[{\"id\":1,\"fecha\":20261101,\"tipo\":\"recarga\",\"monto\":500},{\"id\":2,\"fecha\":20261101,\"tipo\":\"pagoqr\",\"monto\":120,\"comercio\":\"cafe\",\"cashback\":0,\"revertido\":false},{\"id\":3,\"fecha\":20261101,\"tipo\":\"pagoqr\",\"monto\":150,\"comercio\":\"farmacia\",\"cashback\":0,\"revertido\":false},{\"id\":4,\"fecha\":20261102,\"tipo\":\"pagoqr\",\"monto\":200,\"comercio\":\"super\",\"cashback\":0,\"revertido\":false}]}"
		"{\"numero\":70022,\"titular\":\"luis\",\"tipo\":\"premium\",\"saldo\":35,\"movimientos\":[{\"id\":1,\"fecha\":20261101,\"tipo\":\"recarga\",\"monto\":300},{\"id\":2,\"fecha\":20261101,\"tipo\":\"pagoqr\",\"monto\":120,\"comercio\":\"cafe\",\"cashback\":2,\"revertido\":false},{\"id\":3,\"fecha\":20261101,\"tipo\":\"pagoqr\",\"monto\":49,\"comercio\":\"kiosko\",\"cashback\":0,\"revertido\":false},{\"id\":4,\"fecha\":20261101,\"tipo\":\"pagoqr\",\"monto\":100,\"comercio\":\"libreria\",\"cashback\":2,\"revertido\":false}]}" << endl;
	string error;
	// Crear cuentas(numero, titular)
	CuentaBasica ana(70011, "ana");
	CuentaPremium luis(70022, "luis");
	try {
		// Recarga(id, fecha, monto)
		ana.registrar(new Recarga(1, 20261101, 500));
		// PagoQR(id, fecha, monto, comercio)
		ana.registrar(new PagoQR(2, 20261101, 120, "cafe"));
		ana.registrar(new PagoQR(3, 20261101, 150, "farmacia"));
		// otro dia: el limite diario se reinicia
		ana.registrar(new PagoQR(4, 20261102, 200, "super"));
		// premium: cashback de 1 Bs por cada 50 Bs pagados
		luis.registrar(new Recarga(1, 20261101, 300));
		luis.registrar(new PagoQR(2, 20261101, 120, "cafe"));
		luis.registrar(new PagoQR(3, 20261101, 49, "kiosko"));
		luis.registrar(new PagoQR(4, 20261101, 100, "libreria"));
	}
	catch (exception& e) {
		error = e.what();
	}
	string result = ana.toJson() + luis.toJson();
	cout << result << endl;
	cout << error << endl;
	if (error == "" && result == "{\"numero\":70011,\"titular\":\"ana\",\"tipo\":\"basica\",\"saldo\":30,\"movimientos\":[{\"id\":1,\"fecha\":20261101,\"tipo\":\"recarga\",\"monto\":500},{\"id\":2,\"fecha\":20261101,\"tipo\":\"pagoqr\",\"monto\":120,\"comercio\":\"cafe\",\"cashback\":0,\"revertido\":false},{\"id\":3,\"fecha\":20261101,\"tipo\":\"pagoqr\",\"monto\":150,\"comercio\":\"farmacia\",\"cashback\":0,\"revertido\":false},{\"id\":4,\"fecha\":20261102,\"tipo\":\"pagoqr\",\"monto\":200,\"comercio\":\"super\",\"cashback\":0,\"revertido\":false}]}"
		"{\"numero\":70022,\"titular\":\"luis\",\"tipo\":\"premium\",\"saldo\":35,\"movimientos\":[{\"id\":1,\"fecha\":20261101,\"tipo\":\"recarga\",\"monto\":300},{\"id\":2,\"fecha\":20261101,\"tipo\":\"pagoqr\",\"monto\":120,\"comercio\":\"cafe\",\"cashback\":2,\"revertido\":false},{\"id\":3,\"fecha\":20261101,\"tipo\":\"pagoqr\",\"monto\":49,\"comercio\":\"kiosko\",\"cashback\":0,\"revertido\":false},{\"id\":4,\"fecha\":20261101,\"tipo\":\"pagoqr\",\"monto\":100,\"comercio\":\"libreria\",\"cashback\":2,\"revertido\":false}]}")
	{
		cout << "Resultado: correcto" << endl;
		return 20;
	}
	cout << "Resultado: incorrecto" << endl;
	return 0;
}
/*
int pregunta2()
{
	cout << "----Pregunta 2----" << endl;
	string error1, error2, error3, error4;
	CuentaBasica cuenta(70033, "rosa");
	try {
		cuenta.registrar(new Recarga(1, 20261101, 400));
		cuenta.registrar(new PagoQR(2, 20261101, 250, "tienda"));
		// 250 + 60 supera el limite diario de 300
		cuenta.registrar(new PagoQR(3, 20261101, 60, "cine"));
	}
	catch (exception& e) {
		error1 = e.what();
	}
	try {
		// otro dia: no supera el limite, pero el saldo no alcanza
		cuenta.registrar(new PagoQR(4, 20261102, 200, "super"));
	}
	catch (exception& e) {
		error2 = e.what();
	}
	try {
		cuenta.registrar(new Recarga(5, 20261102, 0));
	}
	catch (exception& e) {
		error3 = e.what();
	}
	try {
		// la transaccion 3 fallo, por lo tanto no cuenta para el limite: 250 + 50 = 300
		cuenta.registrar(new PagoQR(6, 20261101, 50, "pan"));
	}
	catch (exception& e) {
		error4 = e.what();
	}
	string result = cuenta.toJson();
	cout << result << endl;
	cout << error1 << endl;
	cout << error2 << endl;
	cout << error3 << endl;
	cout << error4 << endl;
	if (error1 == "la transaccion 3 supera el limite diario de la cuenta 70033"
		&& error2 == "saldo insuficiente en la cuenta 70033 para la transaccion 4"
		&& error3 == "monto invalido en la transaccion 5"
		&& error4 == ""
		&& result == "{\"numero\":70033,\"titular\":\"rosa\",\"tipo\":\"basica\",\"saldo\":100,\"movimientos\":[{\"id\":1,\"fecha\":20261101,\"tipo\":\"recarga\",\"monto\":400},{\"id\":2,\"fecha\":20261101,\"tipo\":\"pagoqr\",\"monto\":250,\"comercio\":\"tienda\",\"cashback\":0,\"revertido\":false},{\"id\":6,\"fecha\":20261101,\"tipo\":\"pagoqr\",\"monto\":50,\"comercio\":\"pan\",\"cashback\":0,\"revertido\":false}]}")
	{
		cout << "Resultado: correcto" << endl;
		return 20;
	}
	cout << "Resultado: incorrecto" << endl;
	return 0;
}
int pregunta3()
{
	cout << "----Pregunta 3----" << endl;
	string error1, error2, error3, error4;
	CuentaPremium cuenta(70044, "eva");
	int cashback = -1;
	try {
		cuenta.registrar(new Recarga(1, 20261110, 1000));
		// cashback 12 -> saldo 412
		cuenta.registrar(new PagoQR(2, 20261110, 600, "tv"));
		// cashback 7 -> saldo 69
		cuenta.registrar(new PagoQR(3, 20261110, 350, "celular"));
		// devuelve 600 - 12 -> saldo 657
		cuenta.revertir(2);
		// el pago 2 revertido ya no cuenta: 350 + 500 = 850 <= 1000; cashback 10 -> saldo 167
		cuenta.registrar(new PagoQR(4, 20261110, 500, "sofa"));
		// cashback de pagos no revertidos: 7 + 10
		cashback = cuenta.totalCashback();
	}
	catch (exception& e) {
		error1 = e.what();
	}
	try {
		cuenta.revertir(2);
	}
	catch (exception& e) {
		error2 = e.what();
	}
	try {
		cuenta.revertir(1);
	}
	catch (exception& e) {
		error3 = e.what();
	}
	try {
		cuenta.revertir(9);
	}
	catch (exception& e) {
		error4 = e.what();
	}
	string result = cuenta.toJson();
	cout << result << endl;
	cout << "totalCashback: " << cashback << endl;
	cout << error1 << endl;
	cout << error2 << endl;
	cout << error3 << endl;
	cout << error4 << endl;
	if (error1 == "" && error2 == "el pago 2 ya fue revertido"
		&& error3 == "la transaccion 1 no es un pago QR"
		&& error4 == "transaccion 9 no encontrada en la cuenta 70044"
		&& cashback == 17
		&& result == "{\"numero\":70044,\"titular\":\"eva\",\"tipo\":\"premium\",\"saldo\":167,\"movimientos\":[{\"id\":1,\"fecha\":20261110,\"tipo\":\"recarga\",\"monto\":1000},{\"id\":2,\"fecha\":20261110,\"tipo\":\"pagoqr\",\"monto\":600,\"comercio\":\"tv\",\"cashback\":12,\"revertido\":true},{\"id\":3,\"fecha\":20261110,\"tipo\":\"pagoqr\",\"monto\":350,\"comercio\":\"celular\",\"cashback\":7,\"revertido\":false},{\"id\":4,\"fecha\":20261110,\"tipo\":\"pagoqr\",\"monto\":500,\"comercio\":\"sofa\",\"cashback\":10,\"revertido\":false}]}")
	{
		cout << "Resultado: correcto" << endl;
		return 25;
	}
	cout << "Resultado: incorrecto" << endl;
	return 0;
}
int pregunta4()
{
	cout << "----Pregunta 4----" << endl;
	string error1, error2, error3, error4, error5;
	// Crear billetera(nombre)
	Billetera b("QRpay");
	int cashback = -1, comisiones = -1, saldoTotal = -1, premium = -1, empresariales = -1, basicas = -1;
	string mayor, texto, result;
	bool igual = false;
	try {
		// registrarCuenta(cuenta): se registran desordenadas, la billetera las ordena por numero
		b.registrarCuenta(new CuentaPremium(70022, "luis"));
		// CuentaEmpresarial(numero, titular, nit)
		b.registrarCuenta(new CuentaEmpresarial(70099, "acme", 1020));
		b.registrarCuenta(new CuentaBasica(70011, "ana"));
		b.registrarCuenta(new CuentaBasica(70011, "otro"));
	}
	catch (exception& e) {
		error1 = e.what();
	}
	try {
		// registrar(numeroCuenta, movimiento)
		b.registrar(70011, new Recarga(1, 20261105, 1000));
		// transferir(id, fecha, origen, destino, monto): ana es basica, comision 2
		b.transferir(2, 20261105, 70011, 70099, 200);
		// destino inexistente: no se modifica ninguna cuenta
		b.transferir(8, 20261105, 70011, 79999, 10);
	}
	catch (exception& e) {
		error2 = e.what();
	}
	try {
		// ana es basica: 200 + 150 supera el limite de 300
		b.transferir(3, 20261105, 70011, 70022, 150);
	}
	catch (exception& e) {
		error3 = e.what();
	}
	try {
		b.mejorarCuenta(70022);
	}
	catch (exception& e) {
		error4 = e.what();
	}
	try {
		b.mejorarCuenta(70011);
		// ana ahora es premium: limite 1000 y sin comision
		b.transferir(4, 20261105, 70011, 70022, 150);
		b.registrar(70099, new Recarga(5, 20261105, 3000));
		// la empresarial tiene limite 5000 (una premium no podria pagar 1500)
		b.registrar(70099, new PagoQR(6, 20261105, 1500, "proveedor"));
		b.registrar(70022, new PagoQR(7, 20261105, 100, "cafe"));
		// revertir(numeroCuenta, idPago)
		b.revertir(70022, 7);
		cashback = b.totalCashback();
		comisiones = b.totalComisiones();
		saldoTotal = b.saldoTotal();
		mayor = b.cuentaMayorSaldo();
		premium = b.contar<CuentaPremium>();
		empresariales = b.contar<CuentaEmpresarial>();
		basicas = b.contar<CuentaBasica>();
		texto = b.buscar(70011)->descripcion() + " | " + b.buscar(70022)->descripcion() + " | " + b.buscar(70099)->descripcion();
		// esIgual compara solo el numero, aunque los tipos de cuenta sean distintos
		CuentaBasica copia(70099, "otro");
		igual = b.buscar(70099)->esIgual(copia);
		result = b.toJson();
	}
	catch (exception& e) {
		error5 = e.what();
	}
	cout << result << endl;
	cout << texto << endl;
	cout << "cashback: " << cashback << " comisiones: " << comisiones << " saldoTotal: " << saldoTotal << " mayor: " << mayor << endl;
	cout << "premium: " << premium << " empresariales: " << empresariales << " basicas: " << basicas << " igual: " << igual << endl;
	cout << error1 << endl;
	cout << error2 << endl;
	cout << error3 << endl;
	cout << error4 << endl;
	cout << error5 << endl;
	if (error1 == "la cuenta 70011 ya existe" && error2 == "cuenta 79999 no encontrada"
		&& error3 == "la transaccion 3 supera el limite diario de la cuenta 70011"
		&& error4 == "la cuenta 70022 no es basica" && error5 == ""
		&& cashback == 30 && comisiones == 2 && saldoTotal == 2528 && mayor == "acme"
		&& premium == 3 && empresariales == 1 && basicas == 0 && igual == true
		&& texto == "[premium] 70011 ana: 648 Bs | [premium] 70022 luis: 150 Bs | [empresarial] 70099 acme: 1730 Bs"
		&& result == "{\"nombre\":\"QRpay\",\"cuentas\":["
		"{\"numero\":70011,\"titular\":\"ana\",\"tipo\":\"premium\",\"saldo\":648,\"movimientos\":[{\"id\":1,\"fecha\":20261105,\"tipo\":\"recarga\",\"monto\":1000},{\"id\":2,\"fecha\":20261105,\"tipo\":\"transferencia\",\"monto\":200,\"destino\":70099,\"comision\":2},{\"id\":4,\"fecha\":20261105,\"tipo\":\"transferencia\",\"monto\":150,\"destino\":70022,\"comision\":0}]},"
		"{\"numero\":70022,\"titular\":\"luis\",\"tipo\":\"premium\",\"saldo\":150,\"movimientos\":[{\"id\":4,\"fecha\":20261105,\"tipo\":\"abono\",\"monto\":150,\"origen\":70011},{\"id\":7,\"fecha\":20261105,\"tipo\":\"pagoqr\",\"monto\":100,\"comercio\":\"cafe\",\"cashback\":2,\"revertido\":true}]},"
		"{\"numero\":70099,\"titular\":\"acme\",\"tipo\":\"empresarial\",\"nit\":1020,\"saldo\":1730,\"movimientos\":[{\"id\":2,\"fecha\":20261105,\"tipo\":\"abono\",\"monto\":200,\"origen\":70011},{\"id\":5,\"fecha\":20261105,\"tipo\":\"recarga\",\"monto\":3000},{\"id\":6,\"fecha\":20261105,\"tipo\":\"pagoqr\",\"monto\":1500,\"comercio\":\"proveedor\",\"cashback\":30,\"revertido\":false}]}]}")
	{
		cout << "Resultado: correcto" << endl;
		return 35;
	}
	cout << "Resultado: incorrecto" << endl;
	return 0;
}
*/
int main()
{
	int nota = pregunta1();// +pregunta2() + pregunta3() + pregunta4();
	cout << endl;
	cout << "====================" << endl;
	cout << "===> NOTA: " << nota << "/100" << endl;
	cout << "====================" << endl;
	system("pause");
	return 0;
}
